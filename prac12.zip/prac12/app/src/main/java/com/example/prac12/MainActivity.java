package com.example.prac12;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DBHelper db;
    EditText editId, editName;
    Button btnInsert, btnUpdate, btnDelete, btnView;
    TextView textViewData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new DBHelper(this);

        editId = findViewById(R.id.editId);
        editName = findViewById(R.id.editName);
        btnInsert = findViewById(R.id.btnInsert);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnDelete = findViewById(R.id.btnDelete);
        btnView = findViewById(R.id.btnView);
        textViewData = findViewById(R.id.textViewData);

        // Insert Data
        btnInsert.setOnClickListener(v -> {
            String name = editName.getText().toString();
            if (name.isEmpty()) {
                Toast.makeText(this, "Please enter name", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean isInserted = db.insertData(name);
            if (isInserted) {
                Toast.makeText(this, "Data Inserted", Toast.LENGTH_SHORT).show();
                editName.setText("");
                textViewData.setText(""); // Clear data view after change
            } else {
                Toast.makeText(this, "Insert Failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Update Data
        btnUpdate.setOnClickListener(v -> {
            String id = editId.getText().toString();
            String name = editName.getText().toString();
            if (id.isEmpty() || name.isEmpty()) {
                Toast.makeText(this, "Please enter ID and Name", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean isUpdated = db.updateData(id, name);
            if (isUpdated) {
                Toast.makeText(this, "Data Updated", Toast.LENGTH_SHORT).show();
                editId.setText("");
                editName.setText("");
                textViewData.setText(""); // Clear data view after change
            } else {
                Toast.makeText(this, "Update Failed (Check ID)", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete Data
        btnDelete.setOnClickListener(v -> {
            String id = editId.getText().toString();
            if (id.isEmpty()) {
                Toast.makeText(this, "Please enter ID", Toast.LENGTH_SHORT).show();
                return;
            }
            boolean isDeleted = db.deleteData(id);
            if (isDeleted) {
                Toast.makeText(this, "Data Deleted", Toast.LENGTH_SHORT).show();
                editId.setText("");
                textViewData.setText(""); // Clear data view after change
            } else {
                Toast.makeText(this, "Delete Failed (Check ID)", Toast.LENGTH_SHORT).show();
            }
        });

        // View Data - ONLY here the data is shown
        btnView.setOnClickListener(v -> {
            Cursor cursor = db.getData();
            if (cursor.getCount() == 0) {
                textViewData.setText("No data found");
                return;
            }

            StringBuilder buffer = new StringBuilder();
            while (cursor.moveToNext()) {
                buffer.append("ID: ").append(cursor.getString(0)).append("\n");
                buffer.append("Name: ").append(cursor.getString(1)).append("\n\n");
            }

            textViewData.setText(buffer.toString());
        });
    }
}
